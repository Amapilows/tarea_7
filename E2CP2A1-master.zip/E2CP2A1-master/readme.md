# Actividad 004 - Landing Page

*INSTRUCCIONES*:

- Para poder realizar este actividad debes haber realizado los cursos previos junto con haber visto los videos online correspondientes a la experiencia 1, 2.

- Dado el layout de la figura que se presenta a continuación, realizar la construcción del HTML y CSS, utilizando los conceptos revisados en las actividades anteriores y seguir las instrucciones de manera local con sublime.

- Luego guarda los cambios y súbelos a Github Pages.

- Luego de pusheados los últimos cambios, sube el link del proyecto en el desafío de la sección correspondiente en la plataforma.

*Hint: Las imágenes que necesitas utilizar las puedes descargar desde el siguiente [enlace](https://github.com/DesafioLatam/E2CP2A1/tree/master/images)*

![Layout](https://github.com/DesafioLatam/E2CP2A1/blob/master/images/landing_latam.png?raw=true)
